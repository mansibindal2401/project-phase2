package com.businessLogic;

public class Booking {
	// flight details
	public static String bid;
	public static int bprice;
	public static String bname;

	// passenger details
	public static String pname;
	public static String pemail;
	public static String pphone;
	public static String aadhar;
	// payment details
	public static String nameoncard;
	public static String carddetails;
}
